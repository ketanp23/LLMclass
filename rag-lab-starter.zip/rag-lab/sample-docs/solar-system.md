# The Solar System (sample lab document)

The Solar System formed about 4.6 billion years ago from the gravitational collapse of a giant molecular cloud. The Sun contains about 99.86 percent of the system's total mass.

The four inner planets, Mercury, Venus, Earth and Mars, are terrestrial planets made mostly of rock and metal. Venus is the hottest planet because its thick carbon dioxide atmosphere traps heat, with surface temperatures around 465 degrees Celsius.

The four outer planets are giants. Jupiter and Saturn are gas giants composed mainly of hydrogen and helium. Uranus and Neptune are ice giants containing water, ammonia and methane ices. Jupiter's Great Red Spot is a storm larger than Earth that has been observed for over 300 years.

The asteroid belt lies between Mars and Jupiter. Beyond Neptune is the Kuiper belt, home to dwarf planets such as Pluto, which was reclassified from planet to dwarf planet by the International Astronomical Union in 2006.
