"""Classroom RAG API: ingest -> chunk -> embed (Ollama) -> store (Qdrant) -> retrieve -> generate (Ollama)."""
import io
import json
import os
import uuid
from collections import Counter

import httpx
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from pypdf import PdfReader
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance, FieldCondition, Filter, FilterSelector, MatchValue, PointStruct, VectorParams,
)

# ---- Configuration (all overridable from docker-compose / .env) ----
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://ollama:11434")
QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")
CHAT_MODEL = os.getenv("CHAT_MODEL", "llama3.2:3b")
COLLECTION = os.getenv("COLLECTION", "classroom_docs")
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "800"))        # characters per chunk
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "150"))  # characters shared by neighbouring chunks
TOP_K = int(os.getenv("TOP_K", "4"))

app = FastAPI(title="Classroom RAG API")
qdrant = AsyncQdrantClient(url=QDRANT_URL)

SYSTEM_PROMPT = (
    "You are a helpful teaching assistant. Answer the question using ONLY the numbered "
    "context passages. Cite the passages you used like [1] or [2]. If the answer is not "
    "in the context, say \"I don't know based on the provided documents.\""
)


# ---------- Helpers ----------
def extract_text(filename: str, data: bytes) -> str:
    name = filename.lower()
    if name.endswith(".pdf"):
        reader = PdfReader(io.BytesIO(data))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if name.endswith((".txt", ".md", ".csv")):
        return data.decode("utf-8", errors="ignore")
    raise HTTPException(400, f"Unsupported file type: {filename} (use .pdf, .txt or .md)")


def chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Fixed-size character chunking with overlap, cutting on whitespace where possible."""
    text = " ".join(text.split())
    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):
            cut = text.rfind(" ", start, end)
            if cut > start + size // 2:
                end = cut
        chunks.append(text[start:end].strip())
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return [c for c in chunks if c]


def with_prefix(texts: list[str], kind: str) -> list[str]:
    """nomic-embed-text was trained with task prefixes; other embedders don't need them."""
    if EMBED_MODEL.startswith("nomic-embed-text"):
        return [f"{kind}: {t}" for t in texts]
    return texts


async def embed(texts: list[str]) -> list[list[float]]:
    async with httpx.AsyncClient(timeout=600) as client:
        r = await client.post(f"{OLLAMA_URL}/api/embed", json={"model": EMBED_MODEL, "input": texts})
        if r.status_code != 200:
            raise HTTPException(502, f"Ollama embed failed: {r.text}")
        return r.json()["embeddings"]


async def ensure_collection(dim: int) -> None:
    if not await qdrant.collection_exists(COLLECTION):
        await qdrant.create_collection(
            COLLECTION, vectors_config=VectorParams(size=dim, distance=Distance.COSINE)
        )


# ---------- API ----------
@app.get("/api/health")
async def health():
    status = {"ollama": False, "qdrant": False, "embed_model": EMBED_MODEL, "chat_model": CHAT_MODEL}
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            status["ollama"] = (await client.get(f"{OLLAMA_URL}/api/tags")).status_code == 200
    except httpx.HTTPError:
        pass
    try:
        await qdrant.get_collections()
        status["qdrant"] = True
    except Exception:
        pass
    return status


@app.get("/api/models")
async def models():
    async with httpx.AsyncClient(timeout=10) as client:
        tags = (await client.get(f"{OLLAMA_URL}/api/tags")).json().get("models", [])
    names = [m["name"] for m in tags if "embed" not in m["name"]]
    return {"default": CHAT_MODEL, "models": names}


@app.post("/api/ingest")
async def ingest(files: list[UploadFile] = File(...)):
    report = []
    for f in files:
        chunks = chunk_text(extract_text(f.filename, await f.read()))
        if not chunks:
            report.append({"file": f.filename, "chunks": 0, "note": "no extractable text"})
            continue
        for i in range(0, len(chunks), 32):  # embed in batches of 32
            batch = chunks[i:i + 32]
            vectors = await embed(with_prefix(batch, "search_document"))
            await ensure_collection(len(vectors[0]))
            points = [
                PointStruct(
                    # Deterministic id: re-uploading the same file overwrites instead of duplicating
                    id=str(uuid.uuid5(uuid.NAMESPACE_URL, f"{f.filename}#{i + j}")),
                    vector=vec,
                    payload={"source": f.filename, "chunk": i + j, "text": chunk},
                )
                for j, (chunk, vec) in enumerate(zip(batch, vectors))
            ]
            await qdrant.upsert(COLLECTION, points=points)
        report.append({"file": f.filename, "chunks": len(chunks)})
    return {"ingested": report}


@app.get("/api/documents")
async def documents():
    if not await qdrant.collection_exists(COLLECTION):
        return {"total_chunks": 0, "documents": []}
    counts, offset = Counter(), None
    while True:
        points, offset = await qdrant.scroll(
            COLLECTION, limit=256, offset=offset, with_payload=["source"], with_vectors=False
        )
        counts.update(p.payload["source"] for p in points)
        if offset is None:
            break
    return {
        "total_chunks": sum(counts.values()),
        "documents": [{"source": s, "chunks": n} for s, n in sorted(counts.items())],
    }


@app.delete("/api/documents/{source}")
async def delete_document(source: str):
    if await qdrant.collection_exists(COLLECTION):
        await qdrant.delete(
            COLLECTION,
            points_selector=FilterSelector(
                filter=Filter(must=[FieldCondition(key="source", match=MatchValue(value=source))])
            ),
        )
    return {"deleted": source}


@app.delete("/api/documents")
async def reset():
    if await qdrant.collection_exists(COLLECTION):
        await qdrant.delete_collection(COLLECTION)
    return {"reset": True}


class Question(BaseModel):
    question: str
    top_k: int = TOP_K
    model: str | None = None


@app.post("/api/ask")
async def ask(q: Question):
    if not await qdrant.collection_exists(COLLECTION):
        raise HTTPException(400, "No documents yet. Upload a file first.")

    # 1) Retrieve: embed the question and find the nearest chunks
    qvec = (await embed(with_prefix([q.question], "search_query")))[0]
    hits = (await qdrant.query_points(COLLECTION, query=qvec, limit=q.top_k, with_payload=True)).points
    sources = [
        {"n": i + 1, "source": h.payload["source"], "chunk": h.payload["chunk"],
         "score": round(h.score, 4), "text": h.payload["text"]}
        for i, h in enumerate(hits)
    ]

    # 2) Augment: put the retrieved chunks into the prompt
    context = "\n\n".join(f"[{s['n']}] (from {s['source']})\n{s['text']}" for s in sources)
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {q.question}"},
    ]

    # 3) Generate: stream tokens back as newline-delimited JSON
    async def stream():
        yield json.dumps({"type": "sources", "data": sources}) + "\n"
        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream(
                "POST", f"{OLLAMA_URL}/api/chat",
                json={"model": q.model or CHAT_MODEL, "messages": messages, "stream": True},
            ) as r:
                if r.status_code != 200:
                    detail = (await r.aread()).decode()
                    yield json.dumps({"type": "error", "data": detail}) + "\n"
                    return
                async for line in r.aiter_lines():
                    if not line:
                        continue
                    data = json.loads(line)
                    token = data.get("message", {}).get("content", "")
                    if token:
                        yield json.dumps({"type": "token", "data": token}) + "\n"
                    if data.get("done"):
                        break
        yield json.dumps({"type": "done"}) + "\n"

    return StreamingResponse(stream(), media_type="application/x-ndjson")
