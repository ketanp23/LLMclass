import os
from pathlib import Path

# Must run before the app is imported: TestModel supports tool-based structured output only
os.environ["OUTPUT_MODE"] = "tool"
os.environ.setdefault("DATA_DIR", str(Path(__file__).resolve().parents[1] / "data"))
