"""Test the agents without Ollama or Qdrant, using Pydantic AI's TestModel.

Run inside the container:  docker compose exec backend pytest -q
TestModel calls every tool once and invents schema-valid outputs, so these tests check the
plumbing (tools, schemas, orchestration, vote counting), not the quality of the answers.
"""
import asyncio
import hashlib

import pytest
from pydantic_ai.messages import ModelResponse, TextPart, ToolCallPart
from pydantic_ai.models.function import FunctionModel
from pydantic_ai.models.test import TestModel
from qdrant_client import AsyncQdrantClient

from app import knowledge as kb
from app import module1, module2


async def fake_embed(texts, kind="search_document"):
    # Deterministic 16-dimensional "embedding" from a hash: good enough to test the plumbing
    return [[b / 255 for b in hashlib.sha256(t.encode()).digest()[:16]] for t in texts]


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    monkeypatch.setattr(kb, "qdrant", AsyncQdrantClient(location=":memory:"))
    monkeypatch.setattr(kb, "embed", fake_embed)
    for mod in (module1, module2):
        monkeypatch.setattr(mod, "get_model", lambda name=None: TestModel())
    asyncio.run(kb.index_research())


def collect(gen):
    async def run():
        return [e async for e in gen]
    return asyncio.run(run())


def test_policy_checks_are_deterministic():
    assert kb.policy_checks(kb.COMPANIES["SOLR"])["hard_limit_failures"] == []
    assert "largest_customer_max_30pct" in kb.policy_checks(kb.COMPANIES["KSTR"])["hard_limit_failures"]
    assert kb.metrics(kb.COMPANIES["KSTR"])["runway_months_after_round"] == "profitable"


def scripted_model(messages, info):
    """A FunctionModel plays the LLM: first it calls tools, then it answers."""
    if len(messages) == 1:
        return ModelResponse(parts=[
            ToolCallPart("recall", {"query": "user preferences"}),
            ToolCallPart("get_financials", {"ticker": "SOLR"}),
            ToolCallPart("search_research_notes", {"query": "risks", "ticker": "SOLR"}),
            ToolCallPart("remember", {"fact": "The user is interested in SOLR"}),
        ])
    return ModelResponse(parts=[TextPart("SOLR grew 94.3% in 2025 (get_financials).")])


def test_assistant_uses_tools_and_memory(monkeypatch):
    monkeypatch.setattr(module1, "get_model", lambda name=None: FunctionModel(scripted_model))
    events = collect(module1.assistant("What is SOLR's growth?", "test", None))
    tools_called = {t["tool"] for t in events[-1]["trace"] if t["kind"] == "call"}
    assert {"get_financials", "search_research_notes", "remember", "recall"} <= tools_called
    assert len(module1.SESSIONS["test"]) == 1          # short-term memory stored the turn


def test_self_consistency_counts_votes():
    events = collect(module2.self_consistency("MDQL", samples=3, temperature=0.9, model=None))
    final = events[-1]
    assert final["type"] == "final"
    assert sum(final["data"]["tally"].values()) == 3


def test_committee_has_four_members_and_a_chair():
    events = collect(module2.committee("URBC", model=None))
    agents = [e["agent"] for e in events if e["type"] == "step"]
    assert len(agents) == 5 and agents[-1] == "Chair"


def test_debate_alternates_sides():
    events = collect(module2.debate("FRMT", rounds=2, model=None))
    agents = [e["agent"] for e in events if e["type"] == "step"]
    assert agents == ["Bull analyst", "Bear analyst", "Bull analyst", "Bear analyst", "Judge"]
