"""Tools the agents can call. Pydantic AI turns the type hints and docstrings into tool schemas."""
import ast
import operator
from dataclasses import dataclass, field

from pydantic_ai import ModelRetry, RunContext

from . import knowledge as kb


@dataclass
class Deps:
    """Dependencies injected into every tool call through RunContext."""
    session_id: str = "default"
    sub_runs: list = field(default_factory=list)   # filled by supervisor delegation tools


def _company(ticker: str) -> dict:
    t = ticker.strip().upper()
    if t not in kb.COMPANIES:
        # ModelRetry sends this message back to the model so it can correct itself
        raise ModelRetry(f"Unknown ticker '{ticker}'. Valid tickers: {', '.join(kb.COMPANIES)}")
    return kb.COMPANIES[t]


async def list_companies(ctx: RunContext[Deps]) -> list[dict]:
    """List every company in the deal pipeline with ticker, name, sector and stage."""
    return [{"ticker": t, "name": c["name"], "sector": c["sector"], "stage": c["stage"]} for t, c in kb.COMPANIES.items()]


async def get_financials(ctx: RunContext[Deps], ticker: str) -> dict:
    """Get reported financials, round terms and calculated metrics (growth, valuation multiple, runway).

    Args:
        ticker: Company ticker, e.g. SOLR.
    """
    c = _company(ticker)
    return {**{k: v for k, v in c.items() if k != "description"}, "calculated": kb.metrics(c)}


async def check_policy(ctx: RunContext[Deps], ticker: str) -> dict:
    """Check a company against the fund's hard investment limits.

    Args:
        ticker: Company ticker, e.g. SOLR.
    """
    return kb.policy_checks(_company(ticker))


async def search_research_notes(ctx: RunContext[Deps], query: str, ticker: str | None = None) -> list[dict]:
    """Semantic search over analyst notes. Call it several times with different queries if needed.

    Args:
        query: What to look for, e.g. 'customer concentration risk'.
        ticker: Optional ticker to search only that company's notes.
    """
    if ticker:
        _company(ticker)
    return await kb.search_research(query, ticker)


async def search_policy(ctx: RunContext[Deps], query: str) -> list[dict]:
    """Search the fund's investment policy document.

    Args:
        query: What to look for, e.g. 'cheque size limits'.
    """
    return await kb.search_research(query, "POLICY")


_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.USub: operator.neg}


def _eval(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.operand))
    raise ValueError("only numbers and + - * / ** are allowed")


async def calculator(ctx: RunContext[Deps], expression: str) -> float:
    """Evaluate an arithmetic expression such as '(41 + 60) / 2.4'. Use it for every calculation.

    Args:
        expression: Arithmetic using numbers, + - * / ** and parentheses.
    """
    try:
        return round(_eval(ast.parse(expression, mode="eval").body), 4)
    except Exception as e:
        raise ModelRetry(f"Could not evaluate '{expression}': {e}")


async def remember(ctx: RunContext[Deps], fact: str) -> str:
    """Save a fact or user preference to long-term memory so it is available in future conversations.

    Args:
        fact: One self-contained sentence, e.g. 'The user focuses on climate-tech deals'.
    """
    await kb.add_memory(fact, ctx.deps.session_id)
    return "saved"


async def recall(ctx: RunContext[Deps], query: str) -> list[str]:
    """Search long-term memory for facts and preferences saved in earlier conversations.

    Args:
        query: What to look for, e.g. 'user preferences'.
    """
    return await kb.search_memory(query)


RESEARCH_TOOLS = [list_companies, get_financials, check_policy, search_research_notes, search_policy, calculator]
