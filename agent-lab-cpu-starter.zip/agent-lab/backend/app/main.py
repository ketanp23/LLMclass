"""Banyan Ridge Capital AI desk: FastAPI routes for both lab modules."""
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI
from pydantic import BaseModel, Field

from . import knowledge as kb
from . import module1, module2
from .config import CHAT_MODEL, EMBED_MODEL, OLLAMA_URL, OUTPUT_MODE
from .events import ndjson


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Build the research knowledge base on first start (the Qdrant volume keeps it afterwards)
    try:
        if not await kb.qdrant.collection_exists(kb.RESEARCH):
            print("Indexing research notes:", await kb.index_research())
    except Exception as e:
        print("Indexing skipped, call POST /api/admin/reindex later:", e)
    yield


app = FastAPI(title="Banyan Ridge AI Desk", lifespan=lifespan)


# ---------- request bodies ----------
class Chat(BaseModel):
    message: str
    session_id: str = "default"
    model: str | None = None


class Question(BaseModel):
    question: str
    model: str | None = None


class CompanyTask(BaseModel):
    ticker: str
    model: str | None = None
    rounds: int = Field(1, ge=1, le=3)      # CPU-friendly defaults: every extra round or sample
    samples: int = Field(3, ge=1, le=7)     # adds model calls that run one after another on CPU
    temperature: float = Field(0.9, ge=0, le=2)


# ---------- info ----------
@app.get("/api/health")
async def health():
    status = {"ollama": False, "qdrant": False, "chat_model": CHAT_MODEL,
              "embed_model": EMBED_MODEL, "output_mode": OUTPUT_MODE}
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            status["ollama"] = (await c.get(f"{OLLAMA_URL}/api/tags")).status_code == 200
    except httpx.HTTPError:
        pass
    try:
        await kb.qdrant.get_collections()
        status["qdrant"] = True
    except Exception:
        pass
    return status


@app.get("/api/models")
async def models():
    async with httpx.AsyncClient(timeout=10) as c:
        tags = (await c.get(f"{OLLAMA_URL}/api/tags")).json().get("models", [])
    return {"default": CHAT_MODEL, "models": [m["name"] for m in tags if "embed" not in m["name"] and "minilm" not in m["name"]]}


@app.get("/api/companies")
async def companies():
    return [{**c, "calculated": kb.metrics(c), "policy": kb.policy_checks(c)} for c in kb.COMPANIES.values()]


@app.post("/api/admin/reindex")
async def reindex():
    return {"indexed": await kb.index_research()}


@app.get("/api/memory")
async def memory():
    return {"long_term": await kb.list_memories(),
            "sessions": {k: len(v) for k, v in module1.SESSIONS.items()}}


@app.delete("/api/memory")
async def forget(session_id: str | None = None):
    """With session_id: clear that chat's short-term memory. Without: clear long-term memory."""
    if session_id:
        module1.SESSIONS.pop(session_id, None)
    else:
        await kb.clear_memories()
    return {"cleared": session_id or "long_term"}


# ---------- Module 1 ----------
@app.post("/api/m1/assistant")
async def m1_assistant(req: Chat):
    return ndjson(module1.assistant(req.message, req.session_id, req.model))


@app.post("/api/m1/workflow")
async def m1_workflow(req: Question):
    return ndjson(module1.workflow(req.question, req.model))


# ---------- Module 2 ----------
@app.post("/api/m2/react")
async def m2_react(req: Question):
    return ndjson(module2.react(req.question, req.model))


@app.post("/api/m2/reflection")
async def m2_reflection(req: CompanyTask):
    return ndjson(module2.reflection(req.ticker.upper(), req.rounds, req.model))


@app.post("/api/m2/self-consistency")
async def m2_self_consistency(req: CompanyTask):
    return ndjson(module2.self_consistency(req.ticker.upper(), req.samples, req.temperature, req.model))


@app.post("/api/m2/supervisor")
async def m2_supervisor(req: Question):
    return ndjson(module2.supervisor(req.question, req.model))


@app.post("/api/m2/committee")
async def m2_committee(req: CompanyTask):
    return ndjson(module2.committee(req.ticker.upper(), req.model))


@app.post("/api/m2/debate")
async def m2_debate(req: CompanyTask):
    return ndjson(module2.debate(req.ticker.upper(), req.rounds, req.model))
