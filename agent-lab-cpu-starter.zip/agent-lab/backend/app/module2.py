"""Module 2: reasoning patterns and multi-agent architectures.
  Reasoning:   react(), reflection(), self_consistency()
  Multi-agent: supervisor() (hierarchical), committee() (parallel + vote), debate() (adversarial)
"""
import asyncio
import json
from collections import Counter
from typing import Literal

from pydantic import BaseModel, Field
from pydantic_ai import Agent, RunContext

from . import knowledge as kb
from .config import get_model, structured
from .events import step
from .tools import RESEARCH_TOOLS, Deps, calculator, check_policy, get_financials, search_policy, search_research_notes

Decision = Literal["INVEST", "WATCHLIST", "PASS"]


# ================================================================ Shared output schemas
class Recommendation(BaseModel):
    decision: Decision
    confidence: float = Field(ge=0, le=1, description="0 to 1")
    key_reasons: list[str] = Field(description="Two or three short reasons")
    main_risk: str


class InvestmentMemo(BaseModel):
    recommendation: Decision
    thesis: str = Field(description="Two or three sentences")
    strengths: list[str]
    risks: list[str]
    valuation_view: str
    policy_fit: str = Field(description="Which hard limits pass or fail, and what that means")


class Critique(BaseModel):
    score: int = Field(ge=1, le=10)
    issues: list[str] = Field(description="Specific problems: wrong numbers, missing risks, weak logic")
    approved: bool


class Opinion(BaseModel):
    stance: Decision
    confidence: float = Field(ge=0, le=1)
    arguments: list[str] = Field(description="Two or three arguments from your specialist angle")
    concerns: list[str]


class CommitteeDecision(BaseModel):
    decision: Decision
    rationale: str
    conditions: list[str] = Field(description="Conditions for investing, or what must change; may be empty")
    dissent: str = Field(description="The strongest minority view")


class Verdict(BaseModel):
    winner: Literal["BULL", "BEAR"]
    decision: Decision
    strongest_bull_point: str
    strongest_bear_point: str
    rationale: str


# ================================================================ 2A. ReAct
react_agent = Agent(
    deps_type=Deps, tools=RESEARCH_TOOLS, retries=2,
    instructions=(
        "You are an investment analyst solving tasks with the ReAct pattern.\n"
        "Loop: write one short line 'Thought: ...' saying what you need next, then call ONE tool (Action), "
        "read the result (Observation), and repeat.\n"
        "Use calculator for all arithmetic. Stop when you have enough evidence and finish with "
        "'Final answer:' followed by a concise answer that cites the numbers you used."
    ),
)


async def react(question: str, model: str | None):
    r = await react_agent.run(question, deps=Deps(), model=get_model(model))
    yield step("ReAct agent", "Thought → Action → Observation loop", r, final=True)


# ================================================================ 2B. Reflection
memo_writer = Agent(
    output_type=structured(InvestmentMemo), retries=3,
    instructions="You are an investment analyst at Banyan Ridge Capital. Write an investment memo using ONLY "
                 "the data pack. Use the calculated metrics and policy checks exactly as given.",
)
critic = Agent(
    output_type=structured(Critique), retries=3,
    instructions="You are a demanding investment-committee partner reviewing a memo. Compare every claim with the "
                 "data pack. Flag wrong numbers, ignored policy failures, missing risks and recommendations that do "
                 "not follow from the evidence. Approve only if the memo is accurate and complete (score 8 or more).",
)


async def reflection(ticker: str, max_rounds: int, model: str | None):
    m = get_model(model)
    pack = await kb.data_pack(ticker)
    w = await memo_writer.run(f"{pack}\n\nWrite the memo.", model=m)
    yield step("Writer", "Draft 1", w)
    memo = w.output
    for i in range(1, max_rounds + 1):
        c = await critic.run(f"{pack}\n\nMEMO TO REVIEW:\n{memo.model_dump_json(indent=1)}", model=m)
        yield step("Critic", f"Critique {i}", c)
        if c.output.approved and c.output.score >= 8:
            yield {"type": "info", "text": f"Critic approved after {i} round(s)"}
            break
        w = await memo_writer.run(
            f"{pack}\n\nYOUR PREVIOUS MEMO:\n{memo.model_dump_json(indent=1)}\n\n"
            f"CRITIQUE TO FIX:\n{json.dumps(c.output.issues)}\n\nWrite an improved memo.", model=m)
        memo = w.output
        yield step("Writer", f"Draft {i + 1} (revised)", w)
    yield {"type": "final", "view": "memo", "data": memo.model_dump()}


# ================================================================ 2C. Self-consistency
quick_analyst = Agent(
    output_type=structured(Recommendation), retries=3,
    instructions="You are an investment analyst. Think about growth, margins, valuation, runway, policy checks "
                 "and risks in the data pack, then give your recommendation.",
)


async def self_consistency(ticker: str, samples: int, temperature: float, model: str | None):
    m = get_model(model)
    pack = await kb.data_pack(ticker)

    async def one(i):
        r = await quick_analyst.run(f"{pack}\n\nShould we invest?", model=m,
                                    model_settings={"temperature": temperature, "seed": i})
        return i, r

    votes = []
    for fut in asyncio.as_completed([one(i) for i in range(samples)]):   # independent samples (queued by Ollama on CPU)
        i, r = await fut
        votes.append(r.output)
        yield step(f"Sample {i + 1}", f"{r.output.decision} ({r.output.confidence:.0%})", r)
    tally = Counter(v.decision for v in votes)
    winner, count = tally.most_common(1)[0]
    agree = [v.confidence for v in votes if v.decision == winner]
    yield {"type": "final", "view": "votes", "data": {
        "decision": winner, "tally": dict(tally), "agreement": round(count / samples, 2),
        "avg_confidence_of_majority": round(sum(agree) / len(agree), 2)}}


# ================================================================ 2D. Supervisor (hierarchical delegation)
financial_specialist = Agent(deps_type=Deps, tools=[get_financials, calculator, check_policy], retries=2,
                             instructions="You are the fund's financial analyst. Answer with numbers from tools. Under 100 words.")
research_specialist = Agent(deps_type=Deps, tools=[search_research_notes], retries=2,
                            instructions="You are the fund's market researcher. Search the notes and summarise what they say. Under 100 words.")
policy_specialist = Agent(deps_type=Deps, tools=[search_policy, check_policy], retries=2,
                          instructions="You are the fund's compliance officer. Answer from the policy and policy checks. Under 100 words.")


async def _delegate(ctx: RunContext[Deps], name: str, agent: Agent, question: str) -> str:
    # usage=ctx.usage adds the specialist's tokens to the supervisor's total
    r = await agent.run(question, deps=ctx.deps, usage=ctx.usage, model=ctx.model)
    ctx.deps.sub_runs.append((name, question, r))
    return r.output


async def ask_financial_analyst(ctx: RunContext[Deps], question: str) -> str:
    """Delegate a question about numbers, growth, valuation or runway to the financial analyst.

    Args:
        question: A self-contained question that names the company ticker.
    """
    return await _delegate(ctx, "Financial analyst", financial_specialist, question)


async def ask_market_researcher(ctx: RunContext[Deps], question: str) -> str:
    """Delegate a question about customers, competition, management or qualitative risks to the researcher.

    Args:
        question: A self-contained question that names the company ticker.
    """
    return await _delegate(ctx, "Market researcher", research_specialist, question)


async def ask_compliance_officer(ctx: RunContext[Deps], question: str) -> str:
    """Delegate a question about the fund's investment policy and hard limits to the compliance officer.

    Args:
        question: A self-contained question.
    """
    return await _delegate(ctx, "Compliance officer", policy_specialist, question)


supervisor_agent = Agent(
    deps_type=Deps, retries=2,
    tools=[ask_financial_analyst, ask_market_researcher, ask_compliance_officer],
    instructions="You lead a team of specialists at an investment fund. Break the request into sub-questions, "
                 "delegate each to the right specialist (you have no data yourself), then combine their answers "
                 "into one clear response of under 200 words that credits each specialist.",
)


async def supervisor(question: str, model: str | None):
    deps = Deps()
    r = await supervisor_agent.run(question, deps=deps, model=get_model(model))
    for name, q, sub in deps.sub_runs:
        yield step(name, f"Delegated: {q}", sub)
    yield step("Supervisor", "Plan, delegate, synthesise", r, final=True)


# ================================================================ 2E. Investment committee (parallel + vote + chair)
ROLES = {
    "Financial analyst": "Focus on growth, margins, cash burn, runway and valuation multiple.",
    "Market analyst": "Focus on market size, competition, customers, retention and moat.",
    "Risk officer": "Focus on what could go wrong: concentration, regulation, execution, debt. Be sceptical.",
    "Compliance officer": "Focus on the fund's hard limits in POLICY CHECKS. A failed hard limit means you "
                          "cannot vote INVEST unless a term-sheet condition would cure it.",
}
members = {
    role: Agent(output_type=structured(Opinion), retries=3,
                instructions=f"You are the {role} on Banyan Ridge Capital's investment committee. {focus} "
                             "Use only the data pack. Vote INVEST, WATCHLIST or PASS.")
    for role, focus in ROLES.items()
}
chair = Agent(
    output_type=structured(CommitteeDecision), retries=3,
    instructions="You chair the investment committee. The decision follows the majority vote, except that INVEST is "
                 "not allowed while a hard limit fails unless you write conditions that cure it. Summarise the "
                 "rationale, list conditions, and record the strongest dissent.",
)


async def committee(ticker: str, model: str | None):
    m = get_model(model)
    pack = await kb.data_pack(ticker)

    async def vote(role):
        return role, await members[role].run(f"{pack}\n\nCast your vote.", model=m)

    opinions = {}
    for fut in asyncio.as_completed([vote(role) for role in members]):
        role, r = await fut
        opinions[role] = r.output.model_dump()
        yield step(role, f"Votes {r.output.stance}", r)
    tally = dict(Counter(o["stance"] for o in opinions.values()))   # counted by code, not by the LLM
    yield {"type": "info", "text": f"Vote tally: {tally}"}
    c = await chair.run(f"{pack}\n\nVOTE TALLY: {tally}\nOPINIONS:\n{json.dumps(opinions, indent=1)}", model=m)
    yield step("Chair", "Committee decision", c)
    yield {"type": "final", "view": "committee", "data": {**c.output.model_dump(), "tally": tally}}


# ================================================================ 2F. Adversarial debate
DEBATE_RULES = ("Use only facts from the data pack and quote numbers exactly. Maximum 120 words. "
                "In rebuttal rounds, attack the opponent's strongest point directly.")
bull = Agent(instructions=f"You are the BULL: argue that the fund SHOULD invest. {DEBATE_RULES}")
bear = Agent(instructions=f"You are the BEAR: argue that the fund should NOT invest. {DEBATE_RULES}")
judge = Agent(output_type=structured(Verdict), retries=3,
              instructions="You are an impartial judge. Decide which side argued better using evidence from the data "
                           "pack, penalise any claim not supported by it, then give the fund's decision.")


async def debate(ticker: str, rounds: int, model: str | None):
    m = get_model(model)
    pack = await kb.data_pack(ticker)
    transcript: list[str] = []
    for rnd in range(1, rounds + 1):
        for side, agent in (("BULL", bull), ("BEAR", bear)):
            task = "Give your opening argument." if rnd == 1 else "Give your rebuttal."
            history = "\n\n".join(transcript) or "(no arguments yet)"
            r = await agent.run(f"{pack}\n\nDEBATE SO FAR:\n{history}\n\nRound {rnd}. {task}", model=m)
            transcript.append(f"{side} (round {rnd}): {r.output}")
            yield step(f"{side.title()} analyst", f"Round {rnd}", r)
    v = await judge.run(f"{pack}\n\nFULL DEBATE:\n" + "\n\n".join(transcript), model=m)
    yield step("Judge", "Verdict", v)
    yield {"type": "final", "view": "verdict", "data": v.output.model_dump()}
