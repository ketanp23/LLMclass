"""Helpers that turn agent runs into events the frontend can draw as a timeline."""
import json
import time
from typing import AsyncIterator

from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from pydantic_ai.messages import ModelResponse, TextPart, ThinkingPart, ToolCallPart, ToolReturnPart


def _short(value, limit: int = 600) -> str:
    s = value if isinstance(value, str) else json.dumps(value, default=str)
    return s if len(s) <= limit else s[:limit] + " …"


def trace(messages: list) -> list[dict]:
    """Thoughts, tool calls and tool results from a run (the final answer is shown separately)."""
    items = []
    last_response = max((i for i, m in enumerate(messages) if isinstance(m, ModelResponse)), default=-1)
    for i, m in enumerate(messages):
        for p in m.parts:
            if isinstance(p, ThinkingPart) and p.content.strip():
                items.append({"kind": "thinking", "text": _short(p.content)})
            elif isinstance(p, TextPart) and p.content.strip() and i != last_response:
                items.append({"kind": "thought", "text": _short(p.content)})
            elif isinstance(p, ToolCallPart) and p.tool_name != "final_result":
                items.append({"kind": "call", "tool": p.tool_name, "args": p.args_as_dict()})
            elif isinstance(p, ToolReturnPart) and p.tool_name != "final_result":
                items.append({"kind": "result", "tool": p.tool_name, "text": _short(p.model_response_str())})
    return items


def output(result):
    o = result.output
    return o.model_dump() if isinstance(o, BaseModel) else o


def step(agent: str, title: str, result, **extra) -> dict:
    """One event describing a finished agent run."""
    usage = result.usage() if callable(result.usage) else result.usage
    return {"type": "step", "agent": agent, "title": title, "output": output(result),
            "trace": trace(result.new_messages()),
            "tokens": (usage.input_tokens or 0) + (usage.output_tokens or 0), **extra}


def ndjson(events: AsyncIterator[dict]) -> StreamingResponse:
    """Stream events as newline-delimited JSON, with timing and error handling."""
    async def gen():
        start = time.perf_counter()
        try:
            async for e in events:
                e.setdefault("elapsed_s", round(time.perf_counter() - start, 1))
                yield json.dumps(e, default=str) + "\n"
        except Exception as exc:   # show the error in the UI instead of a broken stream
            yield json.dumps({"type": "error", "message": f"{type(exc).__name__}: {exc}"}) + "\n"
        yield json.dumps({"type": "done", "elapsed_s": round(time.perf_counter() - start, 1)}) + "\n"
    return StreamingResponse(gen(), media_type="application/x-ndjson")
