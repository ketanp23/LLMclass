"""Settings and the Ollama model factory. Every value can be overridden from .env."""
import os

from pydantic_ai import NativeOutput, PromptedOutput, ToolOutput
from pydantic_ai.settings import ModelSettings
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.ollama import OllamaProvider

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://ollama:11434")
QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")
CHAT_MODEL = os.getenv("CHAT_MODEL", "qwen2.5:3b")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")
OUTPUT_MODE = os.getenv("OUTPUT_MODE", "native")   # native | tool | prompted
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "600"))       # smaller chunks = shorter prompts = faster on CPU
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "100"))
TOP_K = int(os.getenv("TOP_K", "3"))
MEMORY_TURNS = int(os.getenv("MEMORY_TURNS", "4"))   # short-term memory: turns kept per session
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "600"))      # cap on each answer so CPU runs stay short

# Ollama exposes an OpenAI-compatible API at /v1, which Pydantic AI talks to
_provider = OllamaProvider(base_url=f"{OLLAMA_URL}/v1")


def get_model(name: str | None = None) -> OpenAIChatModel:
    # max_tokens applies to every agent; per-run settings (e.g. temperature) are added on top
    return OpenAIChatModel(name or CHAT_MODEL, provider=_provider, settings=ModelSettings(max_tokens=MAX_TOKENS))


def structured(cls):
    """How the model is asked for a typed (Pydantic) answer.
    native   = Ollama constrains generation to the JSON schema (most reliable locally)
    tool     = the model must call a 'final_result' tool with the fields as arguments
    prompted = the schema is pasted into the prompt and the text is parsed as JSON
    """
    return {"native": NativeOutput, "tool": ToolOutput, "prompted": PromptedOutput}[OUTPUT_MODE](cls)
