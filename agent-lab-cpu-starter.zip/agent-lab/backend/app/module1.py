"""Module 1: agent foundations.
  - assistant(): a tool-using agent with short-term memory, long-term memory and agentic RAG
  - workflow():  the same job done as a fixed workflow (routing + prompt chaining) for comparison
"""
from typing import Literal

from pydantic import BaseModel, Field
from pydantic_ai import Agent

from . import knowledge as kb
from .config import MEMORY_TURNS, get_model, structured
from .events import step
from .tools import RESEARCH_TOOLS, Deps, recall, remember

TICKERS = ", ".join(f"{t} ({c['name']})" for t, c in kb.COMPANIES.items())

# ---------------------------------------------------------------- 1A. Agent
assistant_agent = Agent(
    deps_type=Deps,
    tools=[*RESEARCH_TOOLS, remember, recall],
    retries=2,
    instructions=(
        "You are the research assistant for Banyan Ridge Capital, a growth-stage investment fund. "
        f"Pipeline companies: {TICKERS}.\n"
        "Rules:\n"
        "- Use get_financials for numbers and calculator for any arithmetic. Never invent numbers.\n"
        "- Use search_research_notes for qualitative questions; search again with a different query "
        "if the first results do not answer the question (agentic RAG).\n"
        "- Use check_policy or search_policy for questions about the fund's rules.\n"
        "- When the user states a preference or a fact about themselves or their work, call remember.\n"
        "- At the start of a conversation, call recall to look for relevant saved facts.\n"
        "- Answer in under 150 words and say which tool or note each fact came from."
    ),
)

# Short-term memory: the message history of each chat session, kept in RAM
SESSIONS: dict[str, list[list]] = {}


async def assistant(message: str, session_id: str, model: str | None):
    turns = SESSIONS.setdefault(session_id, [])
    history = [m for turn in turns[-MEMORY_TURNS:] for m in turn]
    yield {"type": "info", "text": f"Short-term memory: {len(turns[-MEMORY_TURNS:])} previous turns sent with this message"}
    result = await assistant_agent.run(message, deps=Deps(session_id=session_id),
                                       message_history=history, model=get_model(model))
    turns.append(result.new_messages())
    yield step("Research assistant", "Answer", result)


# ---------------------------------------------------------------- 1B. Workflow
class Route(BaseModel):
    category: Literal["company_analysis", "comparison", "policy_question", "general"]
    tickers: list[str] = Field(default_factory=list, description="Tickers mentioned in the request, e.g. ['SOLR']")
    reason: str = Field(description="One sentence explaining the choice")


router = Agent(
    output_type=structured(Route),
    instructions=(
        f"Classify the user's request for an investment research desk. Known tickers: {TICKERS}. "
        "company_analysis = about one company; comparison = two or more companies; "
        "policy_question = about the fund's rules or mandate; general = anything else. "
        "Map company names to tickers."
    ),
)
analyst = Agent(instructions="You are an investment analyst. Using only the data provided, write a "
                             "150-word analysis covering growth, profitability, valuation, policy fit and key risks.")
brief_writer = Agent(instructions="Rewrite the analysis as an executive brief: three bullet points, then one line "
                                  "starting 'Recommendation:' with INVEST, WATCHLIST or PASS.")
comparer = Agent(instructions="Compare the companies using only the data provided. Give a short table-like "
                              "comparison of growth, margins, valuation multiple and policy failures, then say "
                              "which is the stronger investment and why, in under 200 words.")
policy_answerer = Agent(instructions="Answer the question using only the policy excerpts provided. Quote the rule you rely on.")
generalist = Agent(instructions="You are a helpful assistant at an investment fund. Answer briefly.")


async def workflow(message: str, model: str | None):
    m = get_model(model)
    # Step 1: route (structured output = a validated Route object)
    r = await router.run(message, model=m)
    route = r.output
    route.tickers = [t.upper() for t in route.tickers if t.upper() in kb.COMPANIES]
    yield step("Router", f"Routed to: {route.category}", r)

    if route.category == "company_analysis" and route.tickers:
        # Chain: gather data (code) -> analyse (LLM) -> format (LLM)
        pack = await kb.data_pack(route.tickers[0])
        yield {"type": "info", "text": f"Gathered data pack for {route.tickers[0]} with code, not an LLM ({len(pack)} characters)"}
        a = await analyst.run(f"{pack}\n\nRequest: {message}", model=m)
        yield step("Analyst", "Step 2: analysis", a)
        b = await brief_writer.run(a.output, model=m)
        yield step("Brief writer", "Step 3: executive brief", b, final=True)
    elif route.category == "comparison" and len(route.tickers) >= 2:
        packs = [await kb.data_pack(t) for t in route.tickers[:3]]
        c = await comparer.run("\n\n".join(packs) + f"\n\nRequest: {message}", model=m)
        yield step("Comparer", "Comparison", c, final=True)
    elif route.category == "policy_question":
        # Classic (non-agentic) RAG: always exactly one retrieval, chosen by code
        hits = await kb.search_research(message, "POLICY")
        yield {"type": "info", "text": f"Retrieved {len(hits)} policy chunks (scores: {[h['score'] for h in hits]})"}
        excerpts = "\n\n".join(h["text"] for h in hits)
        p = await policy_answerer.run(f"Policy excerpts:\n{excerpts}\n\nQuestion: {message}", model=m)
        yield step("Policy answerer", "Answer", p, final=True)
    else:
        g = await generalist.run(message, model=m)
        yield step("Generalist", "Answer", g, final=True)
