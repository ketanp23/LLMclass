"""Business data (companies.json), the research knowledge base and long-term memory (both in Qdrant)."""
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

import httpx
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance, FieldCondition, Filter, MatchValue, PointStruct, VectorParams,
)

from .config import CHUNK_OVERLAP, CHUNK_SIZE, DATA_DIR, EMBED_MODEL, OLLAMA_URL, QDRANT_URL, TOP_K

qdrant = AsyncQdrantClient(url=QDRANT_URL)
RESEARCH = "research_notes"
MEMORY = "agent_memory"

# ---------- Structured business data ----------
COMPANIES: dict[str, dict] = {c["ticker"]: c for c in json.loads(Path(DATA_DIR, "companies.json").read_text())}
GM_MIN = {"software": 60, "hardware": 20, "consumer": 25}   # from POLICY.md


def metrics(c: dict) -> dict:
    """Deterministic calculations: LLMs are unreliable at arithmetic, so tools do the maths."""
    rev = c["revenue_musd"]
    post = c["round"]["pre_money_valuation_musd"] + c["round"]["size_musd"]
    burn = c["monthly_burn_musd"]
    return {
        "revenue_growth_2025_pct": round((rev["2025"] / rev["2024"] - 1) * 100, 1),
        "revenue_growth_2024_pct": round((rev["2024"] / rev["2023"] - 1) * 100, 1),
        "post_money_valuation_musd": post,
        "post_money_to_forward_revenue_x": round(post / c["forward_revenue_2026_musd"], 1),
        "runway_months_now": round(c["cash_musd"] / burn, 1) if burn else "profitable",
        "runway_months_after_round": round((c["cash_musd"] + c["round"]["size_musd"]) / burn, 1) if burn else "profitable",
    }


def policy_checks(c: dict) -> dict:
    m = metrics(c)
    runway = m["runway_months_after_round"]
    checks = {
        "valuation_max_15x_forward_revenue": m["post_money_to_forward_revenue_x"] <= 15,
        "runway_min_18_months": runway == "profitable" or runway >= 18,
        "largest_customer_max_30pct": c["largest_customer_share"] <= 0.30,
        f"gross_margin_min_{GM_MIN[c['category']]}pct_for_{c['category']}": c["gross_margin_pct"]["2025"] >= GM_MIN[c["category"]],
        "round_size_within_solo_cheque_range_10_to_80_musd": 10 <= c["round"]["size_musd"] <= 80,
    }
    return {"checks": checks, "hard_limit_failures": [k for k, ok in checks.items() if not ok]}


# ---------- Embeddings ----------
def chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    text = " ".join(text.split())
    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):
            cut = text.rfind(" ", start, end)
            if cut > start + size // 2:
                end = cut
        chunks.append(text[start:end].strip())
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return [c for c in chunks if c]


def _prefix(texts: list[str], kind: str) -> list[str]:
    return [f"{kind}: {t}" for t in texts] if EMBED_MODEL.startswith("nomic-embed-text") else texts


async def embed(texts: list[str], kind: str = "search_document") -> list[list[float]]:
    async with httpx.AsyncClient(timeout=600) as client:
        r = await client.post(f"{OLLAMA_URL}/api/embed", json={"model": EMBED_MODEL, "input": _prefix(texts, kind)})
        r.raise_for_status()
        return r.json()["embeddings"]


async def _ensure(collection: str, dim: int) -> None:
    if not await qdrant.collection_exists(collection):
        await qdrant.create_collection(collection, vectors_config=VectorParams(size=dim, distance=Distance.COSINE))


# ---------- Research knowledge base (for RAG) ----------
async def index_research() -> dict:
    """(Re)build the research collection from data/research/*.md. File stem = company ticker or POLICY."""
    if await qdrant.collection_exists(RESEARCH):
        await qdrant.delete_collection(RESEARCH)
    counts = {}
    for path in sorted(Path(DATA_DIR, "research").glob("*.md")):
        chunks = chunk_text(path.read_text())
        vectors = await embed(chunks)
        await _ensure(RESEARCH, len(vectors[0]))
        await qdrant.upsert(RESEARCH, points=[
            PointStruct(id=str(uuid.uuid4()), vector=v,
                        payload={"company": path.stem.upper(), "file": path.name, "chunk": i, "text": t})
            for i, (t, v) in enumerate(zip(chunks, vectors))
        ])
        counts[path.name] = len(chunks)
    return counts


async def search_research(query: str, company: str | None = None, k: int = TOP_K) -> list[dict]:
    if not await qdrant.collection_exists(RESEARCH):
        return []
    flt = Filter(must=[FieldCondition(key="company", match=MatchValue(value=company.upper()))]) if company else None
    vec = (await embed([query], "search_query"))[0]
    hits = (await qdrant.query_points(RESEARCH, query=vec, query_filter=flt, limit=k, with_payload=True)).points
    return [{"company": h.payload["company"], "score": round(h.score, 3), "text": h.payload["text"]} for h in hits]


# ---------- Long-term (semantic) memory ----------
async def add_memory(fact: str, session_id: str) -> None:
    vec = (await embed([fact]))[0]
    await _ensure(MEMORY, len(vec))
    await qdrant.upsert(MEMORY, points=[PointStruct(
        id=str(uuid.uuid4()), vector=vec,
        payload={"fact": fact, "session_id": session_id, "saved_at": datetime.now(timezone.utc).isoformat()},
    )])


async def search_memory(query: str, k: int = 3) -> list[str]:
    if not await qdrant.collection_exists(MEMORY):
        return []
    vec = (await embed([query], "search_query"))[0]
    hits = (await qdrant.query_points(MEMORY, query=vec, limit=k, with_payload=True, score_threshold=0.4)).points
    return [h.payload["fact"] for h in hits]


async def list_memories() -> list[dict]:
    if not await qdrant.collection_exists(MEMORY):
        return []
    points, _ = await qdrant.scroll(MEMORY, limit=100, with_payload=True, with_vectors=False)
    return sorted((p.payload for p in points), key=lambda p: p["saved_at"])


async def clear_memories() -> None:
    if await qdrant.collection_exists(MEMORY):
        await qdrant.delete_collection(MEMORY)


# ---------- Data pack for tool-less agents ----------
async def data_pack(ticker: str) -> str:
    """Everything an analyst needs about one company, gathered by code (not by the LLM)."""
    c = COMPANIES[ticker]
    notes = await search_research("growth, customers, competition, risks and management", ticker)
    facts = {k: v for k, v in c.items() if k not in ("ticker",)}
    return (
        f"COMPANY: {c['name']} ({ticker})\n"
        f"FACTS: {json.dumps(facts)}\n"
        f"CALCULATED METRICS: {json.dumps(metrics(c))}\n"
        f"POLICY CHECKS: {json.dumps(policy_checks(c))}\n"
        "RESEARCH NOTES:\n" + "\n".join(f"- {n['text']}" for n in notes)
    )
