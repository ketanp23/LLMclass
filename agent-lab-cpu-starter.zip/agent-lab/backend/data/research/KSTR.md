# Kestrel Robotics (KSTR): analyst notes

## Business overview
Kestrel builds autonomous mobile robots that move shelves and totes in warehouses, plus fleet-management software sold as an annual subscription. Customers buy robots upfront or lease them through Robots-as-a-Service contracts.

## Recent performance
Kestrel turned operating-profit positive in 2024 and reached a 6 percent operating margin in 2025, so it does not burn cash. Growth is slowing: revenue grew 41 percent in 2024 but only 23 percent in 2025. Management says the slowdown reflects lumpy deployments at its largest customer.

## Customer concentration
A single national retailer accounts for 41 percent of revenue. That retailer has publicly discussed building an in-house robotics team. Kestrel has 23 customers in total, and the next four largest together make up 25 percent of revenue.

## Customer checks
Customers praise reliability and fast deployment (under ten weeks per site). Two logistics customers said pricing is higher than new Chinese entrants but that Kestrel's support is better.

## Use of funds
The 35 million dollar round would fund an expansion into South-East Asia and a new picking-arm product, which is still in pilot.

## Risks
Customer concentration, low-cost competition, and execution risk on the new product and new geography. Hardware gross margin of 44 percent is healthy for the category.

## Management
The CEO is a former head of operations at a large e-commerce company. The CFO joined from a listed industrial firm. Two independent directors sit on the board.
