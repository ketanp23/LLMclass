# Banyan Ridge Capital: Growth Fund II investment policy (fictional, for teaching)

## Mandate
Growth Fund II invests in technology-enabled companies in India and South-East Asia at Series B through pre-IPO growth rounds. The fund writes cheques of 10 to 80 million US dollars. For rounds larger than 80 million dollars the fund may only participate alongside a co-lead, and its own cheque is capped at 80 million dollars.

## Hard limits (a failure on any of these requires an explicit exception from the full partnership)
1. Valuation: post-money valuation must not exceed 15 times the company's forward (next-year) revenue.
2. Runway: cash after the round, divided by the current monthly burn, must give at least 18 months of runway. Profitable companies pass automatically.
3. Customer concentration: the largest customer must represent no more than 30 percent of revenue.
4. Gross margin minimums by business category: software 60 percent, hardware and energy 20 percent, consumer and marketplace businesses 25 percent.
5. Exclusions: the fund does not invest in tobacco, weapons, gambling or thermal coal.

## Soft guidelines (judgement of the investment committee)
Companies should show a credible path to positive operating margin within 36 months. Net revenue retention above 110 percent is a strong positive signal for recurring-revenue businesses. The committee prefers founders with prior operating experience in the sector and expects at least one independent board member after the round. Regulatory risk must be named and a mitigation plan described in every memo.

## Investment committee process
Every opportunity receives a written memo with a recommendation of INVEST, WATCHLIST or PASS. WATCHLIST means the company is attractive but a specific condition must change before investing. The committee votes by simple majority, but the chair may not approve an INVEST decision when a hard limit fails unless conditions that cure the failure are written into the term sheet.
