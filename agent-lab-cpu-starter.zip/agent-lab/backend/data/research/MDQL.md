# MediQuill (MDQL): analyst notes

## Business overview
MediQuill records doctor-patient conversations (with consent), transcribes them in English and six Indian languages, and drafts discharge summaries and clinical notes inside the hospital's records system. Pricing is per-doctor per-month subscription with multi-year hospital contracts.

## Recent performance
Revenue grew 65 percent in 2025 to 19.5 million dollars with gross margin of 78 percent, helped by cheaper model inference. Operating losses narrowed sharply. Net revenue retention of 132 percent is among the best in the sector because hospitals expand from pilot departments to whole campuses.

## Customer checks
Doctors report saving 60 to 90 minutes per day. However, the largest customer, a national hospital chain, accounts for 34 percent of revenue and its contract renews in nine months. That chain is reportedly also piloting a competing product.

## Incident and regulation
In 2025 one hospital reported that a drafted discharge summary listed a medication the patient was not prescribed; a nurse caught the error before discharge. MediQuill added a mandatory clinician sign-off step afterwards. Draft national guidance on AI in clinical settings may require audit logs and human review for all AI-generated clinical text, which MediQuill says it already supports. Health-data privacy rules require data to stay within India.

## Competition
Global ambient-scribe vendors are entering India, and large records-system vendors are building their own features. MediQuill's advantage is Indian-language accuracy and integrations with local hospital systems.

## Management
The founders are a physician and a former speech-recognition research lead. The company has no independent board member yet.
