# Solara Grid (SOLR): analyst notes

## Business overview
Solara Grid sells containerised lithium-iron-phosphate battery systems paired with its own energy-management software to factories, cold-storage operators and malls that already run rooftop or captive solar. Customers use the batteries to shift solar power into evening peak hours and to cut diesel generator use. About 15 percent of revenue is recurring software and maintenance, and management targets 25 percent by 2027.

## Recent performance
Revenue almost doubled in 2025 to 34 million dollars, driven by a large order book from textile and pharma clusters in Gujarat and Maharashtra. Gross margin improved from 22 to 29 percent as cell prices fell and the company moved battery pack assembly in-house. The order backlog at year end covered roughly 60 percent of the 2026 revenue forecast.

## Customer checks
Eight customer calls were positive about uptime and payback periods of three to four years. Two customers complained about slow service response outside Maharashtra. Net revenue retention of 125 percent reflects customers adding capacity at additional sites.

## Competition
Competitors include large conglomerates entering storage and several Chinese system integrators competing on price. Solara's differentiation is its software, which optimises charging against time-of-day tariffs, and its local service network.

## Risks
The business depends on cell imports, so a rise in lithium prices or new import duties would squeeze margins. State-level changes to net-metering and open-access rules can delay projects. The company carries 12 million dollars of equipment debt. Hardware margins remain thin compared with software businesses.

## Management
The CEO previously ran grid-storage projects at a large utility, and the CTO built battery-management systems at an electric-vehicle maker. The board has one independent director.
