# UrbanCrate (URBC): analyst notes

## Business overview
UrbanCrate operates 380 dark stores across six metro cities and promises delivery of groceries and essentials within 15 minutes. Revenue is the value of goods sold plus delivery and advertising fees charged to brands.

## Recent performance
Revenue grew 73 percent in 2025 to 190 million dollars. Gross margin rose to 19 percent as advertising income and private-label products grew, but the company still loses about 31 cents of operating profit on every dollar of revenue. Monthly cash burn is 7.5 million dollars. Mature dark stores older than 18 months are contribution-margin positive; newer stores are deeply negative.

## Customer checks
Surveys show customers value speed but switch apps freely based on discounts. Average order value is rising slowly. Rider attrition is high and there have been two short rider strikes over pay.

## Competition
Three well-funded national rivals and large e-commerce platforms compete in every city. Competition is largely on discounts and delivery fees, which keeps margins low. Some city governments are examining zoning rules for dark stores in residential areas.

## Round details
The company is raising 120 million dollars. Banyan Ridge has been offered the chance to co-lead alongside a global crossover fund.

## Risks
Path to profitability depends on advertising revenue and store maturity, while rivals keep discounting. 30 million dollars of working-capital debt must be refinanced in 2026. Labour regulation for gig workers is tightening.

## Management
The founding team previously built a successful food-delivery logistics company. The board has two independent directors.
