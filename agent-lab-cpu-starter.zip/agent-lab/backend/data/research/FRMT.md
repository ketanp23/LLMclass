# FarmTrace (FRMT): analyst notes

## Business overview
FarmTrace provides mobile and web software that records farm inputs, harvest lots and quality tests, and produces traceability certificates that exporters need for European and Middle Eastern buyers. It serves farm cooperatives, spice and fruit exporters, and food processors, mostly in Maharashtra, Karnataka and Vietnam.

## Recent performance
Revenue grew 56 percent in 2025 to 5.3 million dollars. Gross margin is 69 percent. The company is still loss-making with an operating margin of minus 35 percent, but losses are narrowing each year. Net revenue retention is 118 percent.

## Market and regulation
New European rules on deforestation-free and traceable supply chains are pushing exporters to adopt digital traceability. This is a tailwind, but the timeline of enforcement has been delayed before. Revenue is seasonal and peaks around harvests.

## Customer checks
Cooperatives like the vernacular-language app that works offline. Exporters say the certificates cut buyer audits from weeks to days. Several small customers are slow to pay.

## Competition
Competitors are mostly small local software firms and global traceability platforms that are expensive for Indian cooperatives.

## Risks
FarmTrace is small. The 12 million dollar round sits at the bottom of the fund's cheque range, so Banyan Ridge would need to take almost the whole round to meet its 10 million dollar minimum. The total addressable market for paid traceability in India is uncertain. The team is thin in sales leadership.

## Management
The founders are an agronomist and a software engineer who previously built farm-advisory apps. There is no independent director yet.
